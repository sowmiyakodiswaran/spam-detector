import streamlit as st
import pickle
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

nltk.download('stopwords')

model = pickle.load(open("model/spam_model.pkl", "rb"))
vectorizer = pickle.load(open("model/vectorizer.pkl", "rb"))
ps = PorterStemmer()

def clean_text(text):
    text = re.sub('[^a-zA-Z]', ' ', text).lower().split()
    return " ".join([ps.stem(w) for w in text if w not in stopwords.words('english')])

st.title("📩 Real-Time Spam Message Detector")
message = st.text_area("Type your message here:")

if st.button("Check Spam"):
    cleaned = clean_text(message)
    vect = vectorizer.transform([cleaned]).toarray()
    result = model.predict(vect)[0]
    if result == 1:
        st.error("⚠️ This is SPAM!")
    else:
        st.success("✅ This is HAM (Safe)")
