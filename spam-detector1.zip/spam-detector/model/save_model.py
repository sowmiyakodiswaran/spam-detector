# model/save_model.py
import pandas as pd
import re
import nltk
import pickle
import os
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

# Download NLTK stopwords
nltk.download('stopwords')

# ✅ Load your already-cleaned CSV with correct columns
df = pd.read_csv('raw/spam.csv', encoding='latin-1')  # 'label' and 'message' already exist

# Clean and preprocess text
ps = PorterStemmer()
def clean_text(text):
    text = re.sub('[^a-zA-Z]', ' ', text).lower().split()
    return " ".join([ps.stem(w) for w in text if w not in stopwords.words('english')])

df['cleaned'] = df['message'].apply(clean_text)

# Vectorize text
cv = CountVectorizer()
X = cv.fit_transform(df['cleaned']).toarray()
y = df['label'].map({'ham': 0, 'spam': 1}).values

# Train the model
model = MultinomialNB()
model.fit(X, y)

# Ensure model/ folder exists
os.makedirs('model', exist_ok=True)

# Save model and vectorizer
pickle.dump(model, open('model/spam_model.pkl', 'wb'))
pickle.dump(cv, open('model/vectorizer.pkl', 'wb'))

# Save cleaned dataset
df.to_csv('model/spam_cleaned.csv', index=False)

print("Model trained and saved successfully.")
